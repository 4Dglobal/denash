<body>
<div class="page-wrapper chiller-theme toggled">
<?php include('header.php');?>
	<main class="page-content">
		<div class="container-fluid p-0">
			<div class="row">
				<div class="col-12 col-md-12 content" style="min-height:780px;">
					<div class="row head-content">
						<div class="col-9 col-md-4 logo"><img src="<?php echo base_url();?>img/logo.jpg"></div>
						<div class="col-3 col-md-8 text-right logout"><a href="<?php echo base_url();?>login/signout">Logout</a></div>
					</div>			
              <div class="row emp-table">
                <h2 style="color:red;">The Page you Looking is NotFound...</h2></div>
                <div style="text-align:center;"><a href="<?php echo base_url();?>home">Click Here To Go For Home Page</a></div>
              
			  </div>
		</div>
	</div>
</main>
</div>
</body>

